<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{promotions}prestashop>promotions_ced2b9f1aad1f8a5b351a3120e4b1212'] = 'Nombre de produit invalide';
$_MODULE['<{promotions}prestashop>promotions_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{promotions}prestashop>promotions_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{promotions}prestashop>promotions_6df1f9b5662398a551a2c9185b26638a'] = 'Pour ajouter des produits à votre page d\'accueil, ajoutez-les simplement à la catégorie \"Accueil\" du catalogue.';
$_MODULE['<{promotions}prestashop>promotions_20c47700083df21a87e47d9299ef4dc4'] = 'Nombre de produits';
$_MODULE['<{promotions}prestashop>promotions_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{promotions}prestashop>promotions_d1aa22a3126f04664e0fe3f598994014'] = 'en promos';
$_MODULE['<{promotions}prestashop>promotions_891ad007e2e9f2d55be6669cd9abc7a0'] = 'plus';
$_MODULE['<{promotions}prestashop>promotions_942a5185d1e828da414e68603741a9bc'] = 'pas de promos!!';
