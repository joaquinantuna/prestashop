<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcomments}matrice>productcomments_7c3b0e9898b88deee7ea75aafd2e37e2'] = 'Note moyenne';
$_MODULE['<{productcomments}matrice>productcomments_b1897515d548a960afe49ecf66a29021'] = 'Moyenne';
$_MODULE['<{productcomments}matrice>productcomments_5da618e8e4b89c66fe86e32cdafde142'] = 'De';
$_MODULE['<{productcomments}matrice>productcomments_b78a3223503896721cca1303f776159b'] = 'Titre';
$_MODULE['<{productcomments}matrice>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Commentaire';
$_MODULE['<{productcomments}matrice>productcomments_08621d00a3a801b9159a11b8bbd69f89'] = 'Aucun commentaire n\'a été publié pour le moment.';
$_MODULE['<{productcomments}matrice>productcomments_6d28f2900adb9e500868166f6d04da92'] = 'Vous devez attendre';
$_MODULE['<{productcomments}matrice>productcomments_30b3dbf8b5c381c2e8d62189048ab37c'] = 'seconde(s) avant de poster un nouveau commentaire.';
$_MODULE['<{productcomments}matrice>productcomments_c3edcf2cedbd4ce230fd6d4ea8915718'] = 'Ajouter un commentaire';
$_MODULE['<{productcomments}matrice>productcomments_a2ed44743411cf8b80e397448fce104c'] = 'Votre nom :';
$_MODULE['<{productcomments}matrice>productcomments_51ec9bf4aaeab1b25bb57f9f8d4de557'] = 'Titre : ';
$_MODULE['<{productcomments}matrice>productcomments_240f3031f25601fa128bd4e15f0a37de'] = 'Commentaire :';
$_MODULE['<{productcomments}matrice>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'Envoyer';
$_MODULE['<{productcomments}matrice>productcomments_720fae7db6e6055d2b47890240bb3598'] = 'Seuls les utilisateurs enregistrés peuvent poster des commentaires.';
$_MODULE['<{productcomments}matrice>products-comparison_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commentaires';
$_MODULE['<{productcomments}matrice>products-comparison_b1897515d548a960afe49ecf66a29021'] = 'Moyenne';
$_MODULE['<{productcomments}matrice>products-comparison_bc976f6c3405523cde61f63a7cbe224b'] = 'Voir les avis';
$_MODULE['<{productcomments}matrice>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Commentaires';
