<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_891ad007e2e9f2d55be6669cd9abc7a0'] = 'plus';
$_MODULE['<{blocknewproducts}matrice>blocknewproducts_d3cf1fa1c9e0e3187f9156ae8c121d06'] = 'pas de nouveaux produits';
