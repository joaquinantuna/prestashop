<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Bienvenue';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Monmon compte';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Me déconnecter';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'déconnexion';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_bffe9a3c9a7e00ba00a11749e022d911'] = 'identifiez-vous';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'panier';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_a2e4822a98337283e39f7b60acf85ec9'] = 'vide';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_f5bf48aa40cad7891eb709fcf1fde128'] = 'produit';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_1bda80f2be4d3658e0baa43fbe7ae8c1'] = 'détails';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_4351cfebe4b61d8aa5efa1d020710005'] = 'détails';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_8b81d9aa118c0c3f760799dcbc9b81c1'] = 'commander';
$_MODULE['<{blockuserinfo}matrice>blockuserinfo_86024cad1e83101d97359d7351051156'] = 'produits';
