<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{crossselling}matrice>crossselling_a1892c39b2598b4f30f9cc92c59f1aa5'] = 'Vendita incrociata';
$_MODULE['<{crossselling}matrice>crossselling_ef2b66b0b65479e08ff0cce29e19d006'] = 'I clienti che hanno acquistato questo prodotto hanno anche comprato ...';
$_MODULE['<{crossselling}matrice>crossselling_e316b4398212d473f7f53c7728fe1c37'] = 'Impostazioni aggiornate con successo';
$_MODULE['<{crossselling}matrice>crossselling_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{crossselling}matrice>crossselling_b6bf131edd323320bac67303a3f4de8a'] = 'Mostra prezzo sui prodotti';
$_MODULE['<{crossselling}matrice>crossselling_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{crossselling}matrice>crossselling_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{crossselling}matrice>crossselling_70f9a895dc3273d34a7f6d14642708ec'] = 'Mostra il prezzo sui prodotti nel blocco.';
$_MODULE['<{crossselling}matrice>crossselling_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{crossselling}matrice>crossselling_dd1f775e443ff3b9a89270713580a51b'] = 'I clienti che hanno acquistato questo prodotto hanno acquistato anche:';
$_MODULE['<{crossselling}matrice>crossselling_4351cfebe4b61d8aa5efa1d020710005'] = 'Precedente';
$_MODULE['<{crossselling}matrice>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Successivo';
