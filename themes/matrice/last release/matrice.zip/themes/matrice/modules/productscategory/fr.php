<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productscategory}matrice>productscategory_4aae87211f77aada2c87907121576cfe'] = 'autres produits dans la même catégorie :';
$_MODULE['<{productscategory}matrice>productscategory_22af645d1859cb5ca6da0c484f1f37ea'] = 'Nouveau';
$_MODULE['<{productscategory}matrice>productscategory_800e90e940e7f1fb938b0fda5137f38c'] = 'En solde!';
$_MODULE['<{productscategory}matrice>productscategory_901b3cbc35bc72fba17d5ccb45afbbc4'] = 'Prix réduit!';
$_MODULE['<{productscategory}matrice>productscategory_d3da97e2d9aee5c8fbe03156ad051c99'] = 'plus';
$_MODULE['<{productscategory}matrice>productscategory_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
