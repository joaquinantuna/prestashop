<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_9e31b08a00c1ed653bcaa517dee84714'] = 'Newsletter Block';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_ba457fab18d697d978befb95e827eb91'] = 'Fügt einen Block für Newsletter-Abos hinzu';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_179bbcbd2e1104cdf9dcecd91264a961'] = 'Sie sind sicher, dass Sie alle Ihre Kontakte löschen wollen?';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_f0e9c1e3969d351170373b5cec2131c2'] = 'Gutschein-Code ist ungültig';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_ff0a3b7f3daef040faf89a88fdac01b7'] = 'Aktualisierung erfolgreich';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_a3399c10bd24eba0b78fbd595c51f81a'] = 'Konfiguration auf einer neuen Seite anzeigen?';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_a6105c0a611b41b08f1209506350279e'] = 'ja';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_7fa3b767c460b54a2be4d49030b349c7'] = 'nein';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_b68ae6efae2fca059754c27ff94494cd'] = 'Bestätigungsmail nach Abonnement senden?';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_506e58042922bff5bd753dc612e84f5b'] = 'Willkommensgutschein-Code';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_de3bd7faad12c79178b1b22bf6119e35'] = 'Zur Deaktivierung leer lassen ';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_06933067aafd48425d67bcb01bba5cb6'] = 'Aktualisierung';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_6e659c47c94d1e1dc7121859f43fb2b0'] = 'Ungültige E-Mail-Adresse';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_9e6df6e72be5be5b8ff962ee3406907e'] = 'E-Mail-Adresse nicht registriert';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_29003419c075963848f1907174bdc224'] = 'Fehler bei der Abo-Abmeldung';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_f7dc297e2a139ab4f5a771825b46df43'] = 'Abo-Abmeldung erfolgreich';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_8dc3b88902df97bb96930282e56ed381'] = 'E-Mail-Adresse bereits registriert';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_b7d9eb38dd2e375648ab08e224e22e43'] = 'Fehler bei der Abonnierung';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_ed3cd7b3cc134222fa70602921ec27e1'] = 'Abonnement erfolgreich';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'Newsletter';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_416f61a2ce16586f8289d41117a2554e'] = 'Ihre E-Mail';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_b26917587d98330d93f87808fc9d7267'] = 'Abonnieren';
$_MODULE['<{blocknewsletter}matrice>blocknewsletter_4182c8f19d40c7ca236a5f4f83faeb6b'] = 'Abmelden';
