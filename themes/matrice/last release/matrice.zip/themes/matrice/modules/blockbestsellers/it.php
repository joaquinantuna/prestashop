<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_6232eaff79c9ccb6c1a66e5a75a212d5'] = 'Blocco migliori vendite';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_95d17a0a1b5ea2de13a3565ed400ebbb'] = 'Aggiungi un blocco che mostra le migliori vendite del negozio';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Conferma';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_530c88f8210e022b39128e3f0409bbcf'] = 'Visualizza sempre blocco';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_a8a670d89a6d2f3fa59942fc591011ef'] = 'Mostra il blocco anche se nessun prodotto è disponibile.';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'Migliori vendite';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'Tutte le migliori vendite';
$_MODULE['<{blockbestsellers}matrice>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'Non ci sono migliori vendite in questo momento';
