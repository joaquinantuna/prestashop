<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}matrice>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'détails';
$_MODULE['<{homefeatured}matrice>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'détails';
$_MODULE['<{homefeatured}matrice>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'panier';
$_MODULE['<{homefeatured}matrice>homefeatured_54013ba69c196820e56801f1ef5aad54'] = 'panier';
$_MODULE['<{homefeatured}matrice>homefeatured_78945de8de090e90045d299651a68a9b'] = 'disponible';
$_MODULE['<{homefeatured}matrice>homefeatured_b55197a49e8c4cd8c314bc2aa39d6feb'] = 'hors stock';
$_MODULE['<{homefeatured}matrice>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Aucun produit phare';
