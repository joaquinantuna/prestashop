<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}matrice>homefeatured_cd2c2dc24eaf11ba856da4a2e2a248be'] = 'Prodotti in vetrina sulla homepage';
$_MODULE['<{homefeatured}matrice>homefeatured_bedd0eb227b31705fce270fe1ec5639f'] = 'Mostra Prodotti in vetrina nel cuore della tua home page';
$_MODULE['<{homefeatured}matrice>homefeatured_dd0de17e8450a0fd3248b19c4a4f803b'] = 'Numero non valido di prodotti';
$_MODULE['<{homefeatured}matrice>homefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{homefeatured}matrice>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{homefeatured}matrice>homefeatured_6df1f9b5662398a551a2c9185b26638a'] = 'Per poter aggiungere prodotti alla tua home page, basta aggiungere alla categoria \"home\".';
$_MODULE['<{homefeatured}matrice>homefeatured_3c230497560c52be92b93c65de9defc9'] = 'Numero di prodotto esposto';
$_MODULE['<{homefeatured}matrice>homefeatured_5bc8290012fcc597689ef8959c2fc969'] = 'Il numero di prodotti esposti in homepage (default: 10)';
$_MODULE['<{homefeatured}matrice>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{homefeatured}matrice>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'prodotti in vetrina';
$_MODULE['<{homefeatured}matrice>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Più';
$_MODULE['<{homefeatured}matrice>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{homefeatured}matrice>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aggiungi al carrello';
$_MODULE['<{homefeatured}matrice>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Nessun prodotto in vetrina';
